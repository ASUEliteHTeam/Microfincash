<?php
session_start();
if (!isset($_SESSION['userid']) && ($_SESSION['logout']=='true'))
{
   echo("<center>Invalid Userid or Password, Click <a href=\"https://www.securetsys.com/mcf/microfincash/login.html\" target=\"_top\">here</a> to logon.</center>");
   $_SESSION['logout']='false';
  exit();
}
require_once "myfunctions.php";
myconnect();
$userid = $_REQUEST['USERID'];
$password = $_REQUEST['PASSWORD'];
?>
<html>


<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", sans-serif}
body, html {
    height: 100%;
    line-height: 1.8;
}
/* Full height image header */
.bgimg-1 {
    background-position: center;
    background-size: cover;
    background-image: url("startup.png");
    min-height: 100%;
}
.w3-bar .w3-button {
    padding: 16px;
}
</style>
</head>
<body>

<!-- Navbar (sit on top) -->
<!========================================================================================================================================>
<div class="w3-top">
  <div class="w3-bar w3-white w3-card-2" id="myNavbar">
    <a href="index.html#home" class="w3-bar-item w3-button w3-wide">RPlusTech MCF</a>
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
      
      <a href="index.html#team" class="w3-bar-item w3-button"><i class="fa fa-usd"></i> BORROW MONEY</a>
      <a href="index.html#work" class="w3-bar-item w3-button"><i class="fa fa-th"></i> LEND & INVEST</a>
      <a href="index.html#pricing" class="w3-bar-item w3-button"><i class="fa fa-usd"></i> SEND/RECEIVE PAYMENTS</a>
      <a href="index.html#ewallet" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> E-WALLET</a>
      <a href="https://www.securetsys.com/mcf/microfincash/sessionlogout.php" Target="_top" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> SIGN-IN/OUT</a>
    </div>
    <!-- Hide right-floated links on small screens and replace them with a menu icon -->

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<!-- Sidebar on small screens when clicking the menu icon -->
<!=======================================================================================================================================>
<nav class="w3-sidebar w3-bar-block w3-black w3-card-2 w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16">Close &times;</a>
  <a href="index.html#team" onclick="w3_close()" class="w3-bar-item w3-button">BORROW MONEY</a>
  <a href="index.html#work" onclick="w3_close()" class="w3-bar-item w3-button">LEND & INVEST</a>
  <a href="index.html#pricing" onclick="w3_close()" class="w3-bar-item w3-button">SEND/RECEIVE PAYMENTS</a>
  <a href="index.html#ewallet" onclick="w3_close()" class="w3-bar-item w3-button">E-WALLET</a>
  <a href="https://www.securetsys.com/mcf/microfincash/sessionlogout.php" target="_top" onclick="w3_close()" class="w3-bar-item w3-button">SIGN-IN/OUT</a>
</nav>


<! Content Starts>

<div class="w3-container" style="padding:128px 16px" id="options">
<div class="w3-row-padding w3-center" style="margin-top:128px">
    <center><h4>RPlusTech MCF</h4></center>
 



<?php

If ($password =="")
   {
    echo("<center><br><br><span style='color:#000000;font-size:14pt; font-family: sans-serif'><buttonred>
<a href=\"https://www.securetsys.com/mcf/microfincash/login.html\"  target=\"_top\" data-role=\"button\" data-theme=\"e\" data-inline=\"true\">Invalid Userid or Password, Click here to sign in.</buttonred></a> 
</span></center>");
        exit(); 
    }


If ($userid =="")
   {
    echo("<center><br><br><span style='color:#000000;font-size:14pt; font-family:sans-serif'><buttonred>
<a href=\"https://www.securetsys.com/mcf/microfincash/login.html\"  target=\"_top\" data-role=\"button\" data-theme=\"e\" data-inline=\"true\">Invalid Userid or Password, Click here to sign in</a></buttonred>
</span></center>");
        exit(); 
    }





$sql="SELECT userid FROM `login_tbl` WHERE `userid`='$userid' and `password`='$password'"; 
$r = mysql_query($sql); 



    if(mysql_affected_rows()==0){
    echo("<center><br><br><span style='color:#000000;font-size:12pt; font-family:sans-serifl'><buttonred>
<a href=\"https://www.securetsys.com/mcf/microfincash/login.html\"  target=\"_top\" data-role=\"button\" data-theme=\"e\" data-inline=\"true\">Invalid Userid or Password, Click here to sign in.</a></buttonred>
</span></center>");
        exit(); 
     }

else
{
$_SESSION['userid'] = $userid;



echo("<br><span style='color:#000000;font-size:12pt; '>
<u><center> Terms of Use</center></u></span>
<br>
<center><span style='color:#000000;font-size:12pt; '> Welcome to RPlusTech Microfinance!</center>
<table>
<tr>
<td width=5>
</td>
<td><center>RPlusTech Microfinance Software Systems can contain sensitive personal records. You may only proceed if you are authorized to access these records.
It is against the law to access these records without the express permission of the owners. If you are in
agreement with the terms and conditions for use of this software, you may proceed.</center>
</td>
<td width=5>
</td>
</tr>
</table>
<br>");
?>

<center>
<a href="https://www.securetsys.com/mcf/microfincash/borrower.html"  target="_top">
Proceed</a></span>
</center>
<?php

}
 

?>


<center>
<span style='color:#000000;font-size:12pt; '>
or
<br>
<a href="https://www.securetsys.com/mcf/microfincash/sessionlogout.php" target="_top">Sign out</a></span>
</center>
</span>
</div>
</div>
<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-black w3-xlarge">
  <a href="#"><i class="fa fa-facebook-official"></i></a>
  <a href="#"><i class="fa fa-pinterest-p"></i></a>
  <a href="#"><i class="fa fa-twitter"></i></a>
  <a href="#"><i class="fa fa-flickr"></i></a>
  <a href="#"><i class="fa fa-linkedin"></i></a>
  <p class="w3-medium">
  (c) Copyright RPlusTech MCF, 2016-2017.
  </p>
</footer>

</body>
</html>