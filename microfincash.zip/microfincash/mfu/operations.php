<?php

?>
<!DOCTYPE html>
<!DOCTYPE html>
<html>
<title>RplusTech MCF</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", sans-serif}
body, html {
    height: 100%;
    line-height: 1.8;
}
/* Full height image header */
.bgimg-1 {
    background-position: center;
    background-size: cover;
    background-image: url("startup.png");
    min-height: 100%;
}
.w3-bar .w3-button {
    padding: 16px;
}
</style>
<body>

<!-- Navbar (sit on top) -->
<!========================================================================================================================================>
<div class="w3-top">
  <div class="w3-bar w3-white w3-card-2" id="myNavbar">
    <a href="index.html#home" class="w3-bar-item w3-button w3-wide">RplusTech MCF</a>
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
      <a href="index.html#about" class="w3-bar-item w3-button">ABOUT</a>    
      <a href="index.html#work" class="w3-bar-item w3-button"><i class="fa fa-th"></i> LEND & INVEST</a>
      <a href="index.html#pricing" class="w3-bar-item w3-button"><i class="fa fa-usd"></i> SEND/RECEIVE PAYMENTS</a>
      <a href="index.html#ewallet" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> E-WALLET</a>
      <a href="https://www.securetsys.com/mcf/microfincash/sessionlogout.php" target="_top" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> SIGN OUT</a>
    </div>
    <!-- Hide right-floated links on small screens and replace them with a menu icon -->

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<!-- Sidebar on small screens when clicking the menu icon -->
<!=======================================================================================================================================>
<nav class="w3-sidebar w3-bar-block w3-black w3-card-2 w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16">Close &times;</a>
  <a href="index.html#about" onclick="w3_close()" class="w3-bar-item w3-button">ABOUT</a>
  <a href="index.html#work" onclick="w3_close()" class="w3-bar-item w3-button">LEND & INVEST</a>
  <a href="index.html#pricing" onclick="w3_close()" class="w3-bar-item w3-button">SEND/RECEIVE PAYMENTS</a>
  <a href="index.html#ewallet" onclick="w3_close()" class="w3-bar-item w3-button">E-WALLET</a>
  <a href="https://www.securetsys.com/mcf/microfincash/sessionlogout.php" target="_top" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i>SIGN OUT</a>
</nav>

<div class="w3-container w3-light-grey" style="padding:128px 16px" id="viewfiles">

<center><h1>View Uploaded Files</h1></center>

<center>

<div class="w3-container">
  <table class="w3-table-all w3-hoverable">
    <tr>
      <th width=3%></th>
      <th width=52%>File<br>Name</th>
            <th width=3%></th>
   </tr>
<!********************************************************************>

<?php
// open the current directory
$dhandle =  opendir( "./uploads");
// define an array to hold the files
$files = array();

if ($dhandle) {
   // loop through all of the files
   while (false !== ($fname = readdir($dhandle))) {
      // if the file is not this file, and does not start with a '.' or '..',
      // then store it for later display
      if (($fname != '.') && ($fname != '..') &&
          ($fname != basename($_SERVER['PHP_SELF']))) {
          // store the filename
          $files[] = (is_dir( "./$fname" )) ? "(Dir) {$fname}" : $fname;
?>
<!**********************************************************************>

<tr>
<td width=3%></td>
<td width=52%>

<?php
          echo("<a href=\"https://www.securetsys.com/mcf/microfincash/mfu/uploads/$fname\">$fname</a><br>");
?>
<!*********************************************************************>
</td>

<td width=3%></td>
</tr>
<?php
      }
   }
   // close the directory
   closedir($dhandle);
}

?>
</table>
<br><br>
<center><a href="..\firstborrower2.html">Proceed with Application Process</a></center>

<hr>
</div>
</div>
<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-black w3-xlarge">
  <a href="#"><i class="fa fa-facebook-official"></i></a>
  <a href="#"><i class="fa fa-pinterest-p"></i></a>
  <a href="#"><i class="fa fa-twitter"></i></a>
  <a href="#"><i class="fa fa-flickr"></i></a>
  <a href="#"><i class="fa fa-linkedin"></i></a>
  <p class="w3-medium">
  (c) Copyright 2017, RplusTech MCF
  </p>
</footer>
</body>
</html>
