<?php


/**
 * Multiple file upload with progress bar php and jquery
 * 
 * Designed by Robert Steven Owor
 * 
 */

?>
<!doctype html>
<!DOCTYPE html>
<html>
<title>RplusTech MCF</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", sans-serif}
body, html {
    height: 100%;
    line-height: 1.8;
}
/* Full height image header */
.bgimg-1 {
    background-position: center;
    background-size: cover;
    background-image: url("startup.png");
    min-height: 100%;
}
.w3-bar .w3-button {
    padding: 16px;
}
</style>
<body>

<!-- Navbar (sit on top) -->
<!========================================================================================================================================>
<div class="w3-top">
  <div class="w3-bar w3-white w3-card-2" id="myNavbar">
    <a href="index.html#home" class="w3-bar-item w3-button w3-wide">RplusTech MCF</a>
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
      <a href="index.html#about" class="w3-bar-item w3-button">ABOUT</a>    
      <a href="index.html#work" class="w3-bar-item w3-button"><i class="fa fa-th"></i> LEND & INVEST</a>
      <a href="index.html#pricing" class="w3-bar-item w3-button"><i class="fa fa-usd"></i> SEND/RECEIVE PAYMENTS</a>
      <a href="index.html#ewallet" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> E-WALLET</a>
      <a href="https://www.securetsys.com/mcf/microfincash/sessionlogout.php" target="_top" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> SIGN OUT</a>
    </div>
    <!-- Hide right-floated links on small screens and replace them with a menu icon -->

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<!-- Sidebar on small screens when clicking the menu icon -->
<!=======================================================================================================================================>
<nav class="w3-sidebar w3-bar-block w3-black w3-card-2 w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16">Close &times;</a>
  <a href="index.html#about" onclick="w3_close()" class="w3-bar-item w3-button">ABOUT</a>
  <a href="index.html#work" onclick="w3_close()" class="w3-bar-item w3-button">LEND & INVEST</a>
  <a href="index.html#pricing" onclick="w3_close()" class="w3-bar-item w3-button">SEND/RECEIVE PAYMENTS</a>
  <a href="index.html#ewallet" onclick="w3_close()" class="w3-bar-item w3-button">E-WALLET</a>
  <a href="https://www.securetsys.com/mcf/microfincash/sessionlogout.php" target="_top" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i>SIGN OUT</a>
</nav>
<br>
<br>
<div class="w3-row-padding" style="margin-top:64px">
<center><h1>Upload Files</h1></center>

<div class="container">	
<br>
	<!-- status message will be appear here -->
	<div class="status"></div>
	
	<!-- multiple file upload form -->
	<form action="upload.php" method="post" enctype="multipart/form-data" class="pure-form">
		<input type="file" name="files[]" multiple="multiple" id="files"><br><br><br>
		<input type="submit" value="Upload" class="pure-button pure-button-primary">
	</form>
	
	<!-- progress bar -->
	<div class="progress">
		<div class="bar"></div >
		<div class="percent">0%</div >
	</div>
<br>
<br>

</div><!-- end .container -->
</div>

	<!-- javascript dependencies -->
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/jquery.form.min.js"></script>
	
	<!-- main script -->
	<script type="text/javascript" src="js/script.js"></script>



<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-black w3-xlarge">
  <a href="#"><i class="fa fa-facebook-official"></i></a>
  <a href="#"><i class="fa fa-pinterest-p"></i></a>
  <a href="#"><i class="fa fa-twitter"></i></a>
  <a href="#"><i class="fa fa-flickr"></i></a>
  <a href="#"><i class="fa fa-linkedin"></i></a>
  <p class="w3-medium">
  (c) Copyright RPlusTech MCF, 2016-2017.
  </p>
</footer>
</body>
</html>