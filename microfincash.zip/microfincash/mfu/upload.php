<?php
?>
<!DOCTYPE html>
<html>
<title>RplusTech MCF</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Raleway", sans-serif}
body, html {
    height: 100%;
    line-height: 1.8;
}
/* Full height image header */
.bgimg-1 {
    background-position: center;
    background-size: cover;
    background-image: url("startup.png");
    min-height: 100%;
}
.w3-bar .w3-button {
    padding: 16px;
}
</style>
<body>

<!-- Navbar (sit on top) -->
<!========================================================================================================================================>
<div class="w3-top">
  <div class="w3-bar w3-white w3-card-2" id="myNavbar">
    <a href="index.html#home" class="w3-bar-item w3-button w3-wide">RplusTech MCF</a>
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
      <a href="index.html#about" class="w3-bar-item w3-button">ABOUT</a>    
      <a href="index.html#work" class="w3-bar-item w3-button"><i class="fa fa-th"></i> LEND & INVEST</a>
      <a href="index.html#pricing" class="w3-bar-item w3-button"><i class="fa fa-usd"></i> SEND/RECEIVE PAYMENTS</a>
      <a href="index.html#ewallet" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> E-WALLET</a>
      <a href="https://www.securetsys.com/mcf/microfincash/sessionlogout.php" target="_top" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> SIGN OUT</a>
    </div>
    <!-- Hide right-floated links on small screens and replace them with a menu icon -->

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<!-- Sidebar on small screens when clicking the menu icon -->
<!=======================================================================================================================================>
<nav class="w3-sidebar w3-bar-block w3-black w3-card-2 w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16">Close &times;</a>
  <a href="index.html#about" onclick="w3_close()" class="w3-bar-item w3-button">ABOUT</a>
  <a href="index.html#work" onclick="w3_close()" class="w3-bar-item w3-button">LEND & INVEST</a>
  <a href="index.html#pricing" onclick="w3_close()" class="w3-bar-item w3-button">SEND/RECEIVE PAYMENTS</a>
  <a href="index.html#ewallet" onclick="w3_close()" class="w3-bar-item w3-button">E-WALLET</a>
  <a href="https://www.securetsys.com/mcf/microfincash/sessionlogout.php" target="_top" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i>SIGN OUT</a>
</nav>
<div class="w3-container w3-light-grey" style="padding:128px 16px" id="contact">

<?php
/**
 * Multiple file upload with progress bar php and jQuery
 * 
 * @Developed by Robert Owor
 * 
 */

$max_size = 1024*100000; // 100MB
$extensions = array('pdf', 'PDF', 'doc', 'DOC', 'docx', 'DOCX', 'txt', 'TXT',  'xls', 'XLS', 'xlsx', 'XLSX', 'jpeg', 'JPEG',  'jpg', 'JPG', 'ppt', 'PPT', 'pptx', 'PPTX', 'png', 'PNG', 'html', 'HTML', 'htm', 'HTM', 'zip', 'ZIP');
$dir = 'uploads/';
$count = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST' and isset($_FILES['files']))
{
	// loop all files
        echo("<center><b><u><h2>Upload Process</h2></u></b></center>");
        echo("<center><b>Files upload started!</b></center><br>");
        echo("<center><b>Files upload in progress .... </b></center><br>");
        
	foreach ( $_FILES['files']['name'] as $i => $name )
	{
		// if file not uploaded then skip it
		if ( !is_uploaded_file($_FILES['files']['tmp_name'][$i]) )
		        {
		        echo("<center>$name was not uploaded</center><br>");
			continue;
			}

	    // skip large files
		if ( $_FILES['files']['size'][$i] >= $max_size )
		        {
		        echo("<center>$name is too big, file was not uploaded</center><br>");
			continue;
			}

		// skip unprotected files
		if( !in_array(pathinfo($name, PATHINFO_EXTENSION), $extensions) )
		        {
		        echo("<center>$name file type not allowed, file not uploaded</center><br>");
			continue;
			}

		// now we can move uploaded files
	    if( move_uploaded_file($_FILES["files"]["tmp_name"][$i], $dir . $name) )
	        {
	        echo("<center>$name uploaded</center><br>");
	    	$count++;
	    	}
	}
}

//echo json_encode(array('count' => $count));
echo("<center><b>Files upload completed!</b></center><br>");
?>

<center>
<buttonred><a href="operations.php">View Uploaded Files</a></buttonred>
<br>
<br>
<buttongreen><a href="myindex.php">More Uploads</a></buttongreen>
<br>
<br>
<buttonred><a href="..\firstborrower2.html">Proceed with Application Process</a></buttonred>
</center>
</div>
<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-black w3-xlarge">
  <a href="#"><i class="fa fa-facebook-official"></i></a>
  <a href="#"><i class="fa fa-pinterest-p"></i></a>
  <a href="#"><i class="fa fa-twitter"></i></a>
  <a href="#"><i class="fa fa-flickr"></i></a>
  <a href="#"><i class="fa fa-linkedin"></i></a>
  <p class="w3-medium">
  (c) Copyright RPlusTech MCF 2017.
  </p>
</footer>
</body>
</html>
