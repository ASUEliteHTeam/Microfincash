<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<title>Home</title>

<style>
a:link {
    color: white;
    background-color: transparent;
    text-decoration: none;
}
a:visited {
    color: white;
    background-color: transparent;
    text-decoration: none;
}
a:hover {
    color: lightblue;
    background-color: transparent;
    text-decoration: none;
}
a:active {
    color: white;
    background-color: transparent;
    text-decoration: none;
}
</style>
<style>
.dropbtn {
    background-color: #000000;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtnyellow {
    background-color: #FDD017;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtnblue {
    background-color: #306EFF;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtnred {
    background-color: #990012;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtngreen {
    background-color: #4CAF50;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtnbrown {
    background-color: #CD7F32;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtnpurple {
    background-color: #7D0541;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #3e8e41;
}
</style>
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 0px solid #ddd;
}

th, td {
    border: none;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>

<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input {display:none;}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>

<script type="text/javascript">$SA = {s:76287, asynch: 1, useBlacklistUrl: 1};(function() {   var sa = document.createElement("script");   sa.type = "text/javascript";   sa.async = true;   sa.src = ("https:" == document.location.protocol ? "https://" + $SA.s + ".sa" : "http://" + $SA.s + ".a") + ".siteapps.com/" + $SA.s + ".js";   var t = document.getElementsByTagName("script")[0];   t.parentNode.insertBefore(sa, t);})();</script>
</head>
<body>

<!-- Navigation -->
<nav>
  <ul class="w3-navbar w3-black">
    <li><a href="../index.html">Home</a></li>
    <li><a href="../aboutus.html">About Us</a></li>
    <li><a href="../serviceprice.html">Services</a></li>
    <li><a href="../contactus.html">Contact</a></li>
    <li><a href="../signin.html">Sign In/Sign Up</a></li>
    <li><a href="../signin.html">My Keys</a></li>
    <li><a href="../sessionlogout.php">Sign Out</a></li>
    <li><a href="myindex.php">More Uploads</a></li>
  </ul>
</nav>
<! End of Navigation>
<br>
<center>
<div class="imgcontainer">
    <img src="../securetsyslogo1.png" border=0 width=250 height=57>
  </div>
</center>
<center><h2>List of Files</h2></center>
<br>

<?php
/**
 * Multiple file upload with progress bar php and jQuery
 * 
 * @Developed by Robert Owor
 * 
 */

?>
<div style="overflow-x:auto;">
  <table>
    <tr>
      <th width=3%></th>
      <th width=52%>File<br>Name</th>
      <th width=22%>Date<br>&Time</th>
      <th with=10%>Select</th>
      <th width=3%></th>
   </tr>
<!********************************************************************>

<?php
// open the current directory
$dhandle =  opendir( "./uploads");
// define an array to hold the files
$files = array();

if ($dhandle) {
   // loop through all of the files
   while (false !== ($fname = readdir($dhandle))) {
      // if the file is not this file, and does not start with a '.' or '..',
      // then store it for later display
      if (($fname != '.') && ($fname != '..') &&
          ($fname != basename($_SERVER['PHP_SELF']))) {
          // store the filename
          $files[] = (is_dir( "./$fname" )) ? "(Dir) {$fname}" : $fname;
?>
<!**********************************************************************>

<tr>
<td width=5%></td>
<td width=50%>

<?php
          echo("$fname<br>");
?>
<!*********************************************************************>
</td>
<td width=20%></td>
<td width=10%>
         <label class="switch">
         <input type="checkbox">
         <div class="slider round"></div>
         </label>
      </td>
<td width=5%></td>
</tr>
<?php
      }
   }
   // close the directory
   closedir($dhandle);
}

?>
</table>
<hr>
<br>
<center><img src="../security1.jpg" width="100%"></center>
<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-black w3-xlarge">
  <a href="#"><i class="fa fa-facebook-official"></i></a>
  <a href="#"><i class="fa fa-pinterest-p"></i></a>
  <a href="#"><i class="fa fa-twitter"></i></a>
  <a href="#"><i class="fa fa-flickr"></i></a>
  <a href="#"><i class="fa fa-linkedin"></i></a>
  <p class="w3-medium">
  (c) Copyright www.securetsys.com, 2016.
  </p>
</footer>
</body>
</html>
