<?php
session_start();
if (!isset($_SESSION['userid']) && ($_SESSION['logout']=='true'))
{
  echo("<center>Invalid Userid or Password, Click <a href=\"https://www.securetsys.com/ad/signin.html\">here</a> to logon.</center>");
  exit();
}
$theuserid=$_SESSION['userid'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.securetsys.com/ad/w3.css">

<title>Main Menu</title>

<style>
a:link {
    color: white;
    background-color: transparent;
    text-decoration: none;
}
a:visited {
    color: white;
    background-color: transparent;
    text-decoration: none;
}
a:hover {
    color: lightblue;
    background-color: transparent;
    text-decoration: none;
}
a:active {
    color: white;
    background-color: transparent;
    text-decoration: none;
}
</style>
<style>
.dropbtn {
    background-color: #000000;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtnyellow {
    background-color: #FDD017;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtnblue {
    background-color: #306EFF;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtnred {
    background-color: #990012;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtngreen {
    background-color: #4CAF50;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtnbrown {
    background-color: #CD7F32;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropbtnpurple {
    background-color: #7D0541;
    color: white;
    padding: 14px;
    font-size: 14px;
    border: none;
    cursor: pointer;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #3e8e41;
}
</style>
</head>
<body>

<!-- Navigation -->
<nav>
  <ul class="w3-navbar w3-black">
    <li><a href="https://www.securetsys.com/ad/index.html">Home</a></li>
    <li><a href="https://www.securetsys.com/ad/aboutus.html">About Us</a></li>
    <li><a href="https://www.securetsys.com/ad/serviceprice.html">Services</a></li>
    <li><a href="https://www.securetsys.com/ad/contactus.html">Contact</a></li>
    <li><a href="signin.html">My Keys</a></li>
    <li><a href="https://www.securetsys.com/ad/sessionlogout.php">Sign Out</a></li>
  </ul>
</nav>
<! End of Navigation>
<br>
<center>
<div class="imgcontainer">
    <img src="securetsyslogo1.png" border=0 width=250 height=57>
  </div>
</center>
<center>
<table>
<tr>
<td width=5>
</td>
<td>
<h5><center> Welcome to SecureTSys Vaults! Here you can secure all your sensitive documents in encrypted vaults which you alone can open using secure encryption and decryption keys.</center></h5>
</td>
<td width=5>
</td>
</tr>
</table>
</center>
<br>

<center>
<table>
<tr>
<td>
<!********************************************************************>

<table>
<tr>
<td bgcolor=#306EFF>
<br>
  <center><a href="operations.php">Birth Certificates</a><center>
<br> 
</td>
</tr>
<tr>
<td bgcolor=#4CAF50>
<br>
  <center><a href="operations.html">Wills</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#CD7F32>
<br>
  <center><a href="operations.html">Academic Transcripts</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#FDD017>
<br>
  <center><a href="operations.html">Academic Certificates</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#990012>
<br>
  <center><a href="operations.html">Resumes and Vitas</a><center>
<br> 
</td>
</tr>


<tr>
<td BGCOLOR=#7D0541>
<br>
  <center><a href="operations.html">References & Support</a><center>
<br> 
</td>
</tr>
</table>
</center>

</td>
<!*****************************************************************************************>




<td>
<!*******************************************************************************************>
<center>
<table>
<tr>
<td BGCOLOR=#7D0541>
<br>
  <center><a href="operations.html">Business Contracts</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#990012>
<br>
  <center><a href="operations.html">Tax Records</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#FDD017>
<br>
  <center><a href="operations.html">Land & Property Titles</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#CD7F32>
<br>
  <center><a href="operations.html">Finance & Accounts</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#4CAF50>
<br>
  <center><a href="operations.html">Insurance & Investments</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#306EFF>
<br>
  <center><a href="operations.html">Medical & Health Records</a><center>
<br> 
</td>
</tr>
</table>
</center>

</td>
<!**************************************************************************************************************>



<td>
<!**************************************************************************************************************>
<center>
<table>
<tr>
<td BGCOLOR=#306EFF>
<br>
  <center><a href="operations.html">Photos & Images</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#4CAF50>
<br>
  <center><a href="operations.html">Electronic Signatures</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#CD7F32>
<br>
  <center><a href="operations.html">Projects & Events</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#FDD017>
<br>
  <center><a href="operations.html">Payments & Receipts</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#990012>
<br>
  <center><a href="operations.html">Miscellaneous</a><center>
<br> 
</td>
</tr>

<tr>
<td BGCOLOR=#7D0541>
<br>
  <center><a href="operations.html">Backup & Restore</a><center>
<br> 
</td>
</tr>
</table>

</td>
<!******************************************************************************************>
</tr>
</table>
</center>
<br>
<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-black w3-xlarge">
  <a href="#"><i class="fa fa-facebook-official"></i></a>
  <a href="#"><i class="fa fa-pinterest-p"></i></a>
  <a href="#"><i class="fa fa-twitter"></i></a>
  <a href="#"><i class="fa fa-flickr"></i></a>
  <a href="#"><i class="fa fa-linkedin"></i></a>
  <p class="w3-medium">
  (c) Copyright www.securetsys.com, 2016.
  </p>
</footer>
</body>
</html>
